
/*  $Id: automachine_middle.c,v 1.1 2005-12-20 21:19:17 debug Exp $  */

/*
 *  automachine_init():
 */
void automachine_init(void)
{
	/*  printf("automachine_init()\n");  */

	/*  automachine_middle.c ends here.  */

